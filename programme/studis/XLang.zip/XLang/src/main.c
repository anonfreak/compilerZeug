/*
 * Project:  COCKTAIL project
 * Descr:    Builds a compiler for XLang
 * Kind:     C-main program
 * Authors:   M. Martin, F.Sinn
 * Version:   V0.2
 * Timestamp: 2017/01/03 13:53
 * State:     Draft
*/

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include "Position.h"
# include "Errors.h"
# include "xlangScan.h"
# include "xlangPars.h"
# include "Tree.h"
# include "xlangAG.h"
# include "xlangPuma.h"

int main(int argc, char *argv[])
{
/*
   Argument checking and help string
*/
   int errors = 0;

   if (argc == 2) {
      if (strcmp(argv[1], "-h") == 0) {
         fprintf(stderr,
         "usage: %s [-h] [file]\n"
         "  expression LR based parser, reads `file' or stdin\n"
         "  -h: Help\n", argv[0]);
         exit(0);
      }

      xlangScan_Attribute.Position.FileName = MakeIdent1(argv[1]);
      xlangScan_BeginFile(argv[1]);
   } else {
      if (argc > 2) {
         fprintf(stderr, "Too many arguments! Use %s -h for help\n", argv[0]);
         exit(1);
      }
      if (argc < 2) {
         fprintf(stderr, "No argument given! Use %s -h for help\n", argv[0]);
         exit(1);
      }
   }

/*
   Initialises the AST data structure
*/
   BeginTree();

/*
   Runs the generated parser, fills the prepared AST
   and prints syntax errors if any occur (xlang.pars etc.)
*/
   errors = xlangPars();
   printf("parser returned: %d number of errors: %d\n",
            errors,
            GetCount(xxError));



/*
   Validates the AST
*/
   if (!CheckTree(TreeRoot)) {
      fprintf(stderr, "Der Baum ist falsch aufgebaut\n");
      exit(1);
   }


/*
   Scans AST for variable names and checks, whether global/local scope is ok
   See .puma file
*/
   declareVariables(TreeRoot);

/*
   Executes all modules listed under EVAL xlangAG (see .ag file):
    * typechecking
    * ...
*/
   xlangAG(TreeRoot);

   checkProcedures(TreeRoot);

/*
   AST output for checking/visualised source code
*/
   SetDepthTree(20);
   SetBoxTree(100, 20);

   DrawTree(TreeRoot);

   /*WriteTree(fopen("treeOut", "w"), TreeRoot);
   */
   return (errors == 0)? 0 : 1;
}
